from __future__ import annotations

from typing import Iterable

import requests

# === LEGACY / ОПЦИОНАЛЬНО ===
# Бот (bot.py) НЕ использует этот файл и НЕ отправляет в Google Form при /архив.
# Это только если хочешь вручную сохранить данные в форму как бэкап.
# Пользователь сказал: забудь про форму и App Script, используй только бота для Discord.
# Можно удалить этот файл и requests из requirements если не нужен.

FORM_RESPONSE_URL = (
    "https://docs.google.com/forms/d/e/"
    "1FAIpQLScNOLbLnnpKOozCnyQdqNd8Qd8xcndXvsXIccQpza6fF_PQvA/formResponse"
)

ENTRY_PROSECUTOR = "132769743"
ENTRY_SUBJECTS = "1160342597"
ENTRY_STRUCTURE = "411805549"
ENTRY_DOCS_LINK = "712155587"
ENTRY_CASE_NUMBER = "1241043974"
ENTRY_REASON = "PLACEHOLDER_REPLACE_ME"  # TODO: замени на реальный ID поля "Повод для возбуждения" из Google Form (чтобы сохранялось в ответах формы).
# Как найти: открой форму /viewform в браузере → правой кнопкой на поле "Повод для возбуждения" → Inspect
# → найди <input name="entry.XXXXXXXXX"> (или в JS data) и скопируй число после entry.
# Примечание: даже с placeholder, отправка формы проходит (неизвестные entry игнорируются Google).
# Данные "повод" ВСЁ РАВНО попадают в Discord (частичный embed в ch1 + ПОЛНЫЙ в ch2) — бот берёт их напрямую из аргументов /архив.
# Замени только если хочешь, чтобы "повод" сохранялся в Google таблице ответов формы.


class FormSubmitError(Exception):
    pass


def _normalize_structures(structures: Iterable[str]) -> list[str]:
    result: list[str] = []
    for raw in structures:
        name = raw.strip().upper()
        if not name:
            continue
        if name not in result:
            result.append(name)
    # Allow empty - user can write whatever they want for структура too (except link)
    return result


def submit_archive_case(
    prosecutor: str,
    subjects: str,
    structures: Iterable[str],
    docs_link: str,
    case_number: str,
    reason: str,
) -> None:
    prosecutor = prosecutor.strip()
    subjects = subjects.strip()
    docs_link = docs_link.strip()
    case_number = case_number.strip()
    reason = reason.strip()

    if not prosecutor:
        raise FormSubmitError("Имя прокурора не может быть пустым.")
    if not subjects:
        raise FormSubmitError("Субъекты дела не могут быть пустыми.")
    if not docs_link.startswith("http"):
        raise FormSubmitError("Ссылка на Google Docs должна начинаться с http(s)://")
    if not reason:
        raise FormSubmitError("Повод для возбуждения не может быть пустым.")

    structure_list = _normalize_structures(structures)

    data: list[tuple[str, str]] = [
        (f"entry.{ENTRY_PROSECUTOR}", prosecutor),
        (f"entry.{ENTRY_SUBJECTS}", subjects),
        (f"entry.{ENTRY_DOCS_LINK}", docs_link),
        (f"entry.{ENTRY_CASE_NUMBER}", case_number),
        (f"entry.{ENTRY_REASON}", reason),
    ]
    for structure in structure_list:
        data.append((f"entry.{ENTRY_STRUCTURE}", structure))

    response = requests.post(
        FORM_RESPONSE_URL,
        data=data,
        timeout=30,
        allow_redirects=False,
    )
    # Google Forms отвечает 200 или 302 при успехе
    if response.status_code not in (200, 302):
        raise FormSubmitError(f"Форма вернула код {response.status_code}.")
