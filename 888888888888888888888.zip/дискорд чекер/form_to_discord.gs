/**
 * Google Apps Script: LEGACY / ОПЦИОНАЛЬНЫЙ БЭКАП (ПОЛЬЗОВАТЕЛЬ СКАЗАЛ ЗАБУДЬ ПРО НЕГО)
 *
 * ВСЁ ДЕЛАЕТ ТОЛЬКО Python бот из https://discord.com/developers/applications/1512243251120312321/bot
 * Никаких постов в Discord из GAS, вебхуков, ротаций.
 *
 * Бот сам принимает /архив в ch1 → шлёт в ch1 (частично) и ch2 (полностью).
 * Этот скрипт — если вообще оставить — только чтобы форма сохраняла ответы как бэкап.
 * Можно вообще удалить триггер onSubmit и сам файл.
 *
 * onSubmit сейчас ничего не отправляет.
 */

// === ОТКЛЮЧЕНО ===
// Всё ниже (USERNAME, AVATAR, collect, send* ) оставлено на случай, если понадобится вернуть отправку из GAS.
// Сейчас не используется. Discord посты — только из bot.py.
const USERNAME = "Секретутка Генерала Паркуров";
const AVATAR_URL = "https://media.discordapp.net/attachments/1399837376297046139/1401313273076387955/321.png";

// === ОСНОВНАЯ ФУНКЦИЯ (вызывается Google Form при отправке) ===
// Discord-посты ОТКЛЮЧЕНЫ. Всё делает только Python бот (bot.py).
function onSubmit(e) {
  try {
    if (!e || !e.response) {
      Logger.log("Событие формы не получено.");
      return;
    }

    // Просто логируем, что ответ пришёл в Google Form.
    // Никаких отправок в Discord отсюда (по требованию — только бот из Discord Developer).
    Logger.log("Форма принята и сохранена в Google. Discord-уведомления делает только bot.py.");

    // Если очень нужно вернуть пост полного архива из GAS — раскомментируй ниже:
    // const responses = e.response.getItemResponses();
    // const fields = collectResponseFields(responses);
    // sendFullArchiveViaBot(fields);

  } catch (err) {
    Logger.log("Ошибка: " + err.toString());
  }
}

/**
 * Собирает поля из ответов формы (логика близка к старой версии).
 */
function collectResponseFields(itemResponses) {
  const fields = [];

  itemResponses.forEach(item => {
    const question = item.getItem().getTitle();
    let answer = item.getResponse();

    if (answer === null || answer === undefined || answer === "") return;

    if (Array.isArray(answer)) {
      answer = answer.join(", ");
    } else {
      answer = String(answer);
    }

    let chunks = [];
    try {
      chunks = answer.match(/[\s\S]{1,1024}/g) || [answer];
    } catch (e) {
      chunks = [answer];
    }

    chunks.forEach((chunk, index) => {
      fields.push({
        name: index === 0 ? question : question + " (продолжение)",
        value: chunk,
        inline: false
      });
    });
  });

  return fields;
}

// === ОТПРАВКА ПОЛНОГО АРХИВА (ВСЕ поля, без жёсткого ограничения 25) ===
// Делит на несколько сообщений, если полей > 25 (лимит Discord на embed).
function sendFullArchiveViaBot(allFields) {
  // ОТКЛЮЧЕНО: Discord посты делает только bot.py
  Logger.log("sendFullArchiveViaBot вызван, но отключён (только бот).");
  return;

  const props = PropertiesService.getScriptProperties();
  const token = props.getProperty("DISCORD_BOT_TOKEN");
  const channelId = props.getProperty("FULL_LOG_CHANNEL_ID");

  if (!token || !channelId) {
    Logger.log("ОШИБКА: Не настроен бот. Запусти setupBotConfig() с токеном.");
    return;
  }

  if (!allFields || allFields.length === 0) {
    Logger.log("Нет полей для полного архива.");
    return;
  }

  const CHUNK_SIZE = 25; // Discord embed fields max
  const totalChunks = Math.ceil(allFields.length / CHUNK_SIZE);

  for (let i = 0; i < totalChunks; i++) {
    const chunk = allFields.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);
    const isFirst = (i === 0);
    const isLast = (i === totalChunks - 1);

    const title = isFirst
      ? "ПОЛНАЯ РЕГИСТРАЦИЯ ДЕЛА — АРХИВ"
      : "ПОЛНАЯ РЕГИСТРАЦИЯ ДЕЛА — АРХИВ (продолжение " + (i + 1) + "/" + totalChunks + ")";

    const desc = isFirst
      ? "Полная копия всех ответов формы из Google Form. Отправлено ботом в архив."
      : "Продолжение полных ответов формы.";

    const payload = {
      username: USERNAME,
      avatar_url: AVATAR_URL,
      embeds: [{
        color: 3447003, // синий — полный архив
        title: title,
        description: desc,
        fields: chunk,
        timestamp: new Date().toISOString()
      }]
    };

    const ok = sendOneBotMessage(payload, channelId, token);
    if (!ok) {
      Logger.log("Не удалось отправить часть архива #" + (i + 1));
      // продолжаем, чтобы отправить остальные части
    }

    // Небольшая пауза между сообщениями, чтобы не словить 429
    if (!isLast) {
      Utilities.sleep(800);
    }
  }

  Logger.log("Полный архив отправлен ботом в канал 1511785094141051051 (" + totalChunks + " сообщений).");
}

// Низкоуровневая отправка — отключена
function sendOneBotMessage(payload, channelId, token) {
  Logger.log("sendOneBotMessage отключён.");
  return;
  const url = `https://discord.com/api/v10/channels/${channelId}/messages`;

  const options = {
    method: "post",
    contentType: "application/json",
    headers: { "Authorization": "Bot " + token },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  Logger.log("Отправка ботом (полный архив) в " + channelId + "...");

  let resp = UrlFetchApp.fetch(url, options);
  let code = resp.getResponseCode();
  let body = resp.getContentText();

  Logger.log("Код (бот): " + code);

  if (code === 429) {
    const delay = Math.min(getRateLimitDelayMs(resp, body), 20000);
    Logger.log("429 от бота — ждём " + delay + " мс и повторяем...");
    Utilities.sleep(delay);
    resp = UrlFetchApp.fetch(url, options);
    code = resp.getResponseCode();
    body = resp.getContentText();
    Logger.log("Повторный код бота: " + code);
  }

  const success = (code >= 200 && code < 300);
  if (success) {
    Logger.log("Часть архива успешно отправлена ботом.");
  } else {
    Logger.log("Ошибка отправки ботом: " + body);
  }
  return success;
}

// Старое имя — отключено
function sendToDiscordBot(payload) {
  Logger.log("sendToDiscordBot отключён (только Python бот).");
  return;
}

/**
 * Задержка при rate limit (429 / error 1015).
 */
function getRateLimitDelayMs(response, bodyText) {
  const def = 12000;
  try {
    const headers = response.getHeaders ? response.getHeaders() : {};
    const ra = headers['retry-after'] || headers['Retry-After'];
    if (ra) {
      const v = parseFloat(ra);
      if (!isNaN(v) && v > 0) return Math.ceil(v * 1000) + 400;
    }
  } catch (e) {}

  try {
    const text = bodyText || (response.getContentText ? response.getContentText() : "");
    const data = JSON.parse(text || "{}");
    if (data.retry_after) {
      const v = parseFloat(data.retry_after);
      if (!isNaN(v) && v > 0) return Math.ceil(v * 1000) + 400;
    }
    if (data.error_code === 1015) return 18000;
    if (text.indexOf("1015") > -1 || text.toLowerCase().indexOf("rate limited") > -1) return 18000;
  } catch (e) {}
  return def;
}

// === НАСТРОЙКА ===

/**
 * setupBotConfig — больше не нужен (Discord посты только из bot.py).
 * Можно удалить или оставить закомментированным.
 */
// function setupBotConfig() { ... }

/**
 * (Опционально) Можно запустить для проверки отправки полного архива.
 * Перед этим: setupBotConfig() с реальным токеном.
 */
function testBotSend() {
  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty("DISCORD_BOT_TOKEN") || !props.getProperty("FULL_LOG_CHANNEL_ID")) {
    Logger.log("Сначала запусти setupBotConfig()!");
    return;
  }

  // Тестовые поля (имитируем несколько, чтобы проверить chunking при >25)
  const testFields = [];
  for (let i = 1; i <= 7; i++) {
    testFields.push({ name: "Тестовое поле " + i, value: "Значение поля " + i + " (полные данные из формы)", inline: false });
  }

  const payload = {
    username: USERNAME,
    avatar_url: AVATAR_URL,
    embeds: [{
      color: 3447003,
      title: "ПОЛНАЯ РЕГИСТРАЦИЯ (тест бота)",
      description: "Тест отправки ПОЛНОЙ версии в архив 1511785094141051051",
      fields: testFields,
      timestamp: new Date().toISOString()
    }]
  };
  sendToDiscordBot(payload);
}

// === УСТАРЕВШИЕ (закомментированы, т.к. регистрация теперь в bot.py) ===
// function initializeRotation() { ... }
// function showCurrentIndex() { ... }
// function testSend() { ... }  // раньше слал частичную регистрацию через webhook'и

