﻿@echo off
chcp 65001 >nul 2>&1

echo.
echo ================================================
echo   Invite Discord Bot "Archive of cases"
echo ================================================
echo.
echo 1. Go to: https://discord.com/developers/applications
echo 2. Select your application (the one with this bot)
echo 3. Go to: OAuth2 -^> URL Generator (left menu)
echo 4. In SCOPES check:
echo      - bot
echo      - applications.commands
echo 5. In BOT PERMISSIONS select at least:
echo      - Send Messages
echo      - Embed Links
echo      - Use Slash Commands
echo      (you can select more if needed)
echo 6. Scroll down and COPY the generated URL
echo 7. Open that URL in your browser and add the bot to your server (the one with ID 1511773307035451443)
echo.
echo ------------------------------------------------
echo Ready-made invite link (just replace if needed):
echo.
echo https://discord.com/api/oauth2/authorize?client_id=1512243251120312321^&permissions=2147485696^&scope=bot+applications.commands
echo.
echo (This link uses the correct Client ID for your bot)
echo ------------------------------------------------
echo.
echo After you add the bot to the server:
echo   - Run start.bat or python bot.py
echo   - The slash commands should appear quickly because GUILD_ID is set
echo.
echo Press any key to exit...
pause >nul
