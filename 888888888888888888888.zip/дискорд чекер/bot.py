"""Discord-бот «Архив дел»: /архив принимает данные в канале 1, шлёт частичный embed туда же + ПОЛНЫЙ embed в канал 2 (архив).
ИСПОЛЬЗУЕТСЯ ТОЛЬКО БОТ ИЗ DISCORD DEVELOPER (никаких Google Apps Script, вебхуков, формы для Discord-постов).
Google Form (если используется) — только ручной бэкап, НЕ часть команды.
"""

from __future__ import annotations

import logging
import os
import sys

import discord
from discord import app_commands
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("archive_bot")

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
CHANNEL_ID_RAW = os.getenv("CHANNEL_ID", "").strip()
GUILD_ID_RAW = os.getenv("GUILD_ID", "").strip()
ARCHIVE_CHANNEL_ID_RAW = os.getenv("ARCHIVE_CHANNEL_ID", "1511785094141051051").strip()

if not TOKEN:
    log.error("DISCORD_TOKEN не задан. Создайте файл .env рядом с bot.py")
    sys.exit(1)

try:
    ALLOWED_CHANNEL_ID = int(CHANNEL_ID_RAW)
except ValueError:
    log.error("CHANNEL_ID должен быть числом (ID канала Discord).")
    sys.exit(1)

ARCHIVE_CHANNEL_ID: int | None = None
if ARCHIVE_CHANNEL_ID_RAW:
    try:
        ARCHIVE_CHANNEL_ID = int(ARCHIVE_CHANNEL_ID_RAW)
    except ValueError:
        log.error("ARCHIVE_CHANNEL_ID должен быть числом (ID канала архива).")
        sys.exit(1)

GUILD_ID: int | None = None
if GUILD_ID_RAW:
    try:
        GUILD_ID = int(GUILD_ID_RAW)
    except ValueError:
        log.error("GUILD_ID должен быть числом (ID сервера Discord).")
        sys.exit(1)

ADMIN_IDS: set[int] = set()
ADMIN_IDS_RAW = os.getenv("ADMIN_IDS", "").strip()
if ADMIN_IDS_RAW:
    for part in ADMIN_IDS_RAW.replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            ADMIN_IDS.add(int(part))
        except ValueError:
            log.warning("ADMIN_IDS содержит некорректный ID (пропущен): %s", part)


def _add_field_safe(embed: discord.Embed, name: str, value: str | None, inline: bool = False) -> None:
    """Add a field to embed, auto-splitting long values (>1024 chars) into continuation fields.
    This prevents 'embed field value too long' errors that would cause the send to ch2 (or ch1) to fail.
    """
    val = (value or "—").strip()
    if not val:
        val = "—"
    max_len = 1024
    if len(val) <= max_len:
        embed.add_field(name=name, value=val, inline=inline)
        return
    chunks = [val[i : i + max_len] for i in range(0, len(val), max_len)]
    for i, chunk in enumerate(chunks):
        fname = name if i == 0 else f"{name} (продолжение {i + 1})"
        embed.add_field(name=fname, value=chunk, inline=inline)


class ArchiveBot(discord.Client):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        # Привилегированные интенты (members, presences, message_content) НЕ включаем.
        # Иначе бот упадёт с PrivilegedIntentsRequired при подключении,
        # пока они не будут явно включены в Discord Developer Portal для приложения.
        # Если понадобится on_message или доступ к member'ам — добавь здесь + включи в портале.
        super().__init__(intents=intents)
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self) -> None:
        synced_to_guild = False
        if GUILD_ID is not None:
            guild = discord.Object(id=GUILD_ID)
            self.tree.copy_global_to(guild=guild)
            try:
                await self.tree.sync(guild=guild)
                log.info("Slash-команды на сервере %s (появятся сразу).", GUILD_ID)
                synced_to_guild = True
            except discord.Forbidden:
                log.warning(
                    "Нет доступа к серверу %s — сначала добавь бота через invite.bat, затем перезапусти.",
                    GUILD_ID,
                )
            except Exception:
                log.exception("Неожиданная ошибка при синхронизации команд на сервере %s", GUILD_ID)

        try:
            await self.tree.sync()
            if synced_to_guild:
                log.info("Slash-команды также синхронизированы глобально (до ~1 часа на других серверах).")
            else:
                log.info("Slash-команды синхронизированы глобально (появятся до ~1 часа).")
        except Exception:
            log.exception("Ошибка при глобальной синхронизации slash-команд")


bot = ArchiveBot()


def _channel_ok(interaction: discord.Interaction) -> bool:
    # Exact match (main channel)
    if interaction.channel_id == ALLOWED_CHANNEL_ID:
        return True

    # Support threads / forum posts inside the allowed channel
    ch = interaction.channel
    if ch is not None and hasattr(ch, "parent") and ch.parent is not None:
        if ch.parent.id == ALLOWED_CHANNEL_ID:
            return True

    # Debug log
    log.warning("Channel check failed. interaction.channel_id=%s, expected=%s", interaction.channel_id, ALLOWED_CHANNEL_ID)
    return False


def _is_admin(interaction: discord.Interaction) -> bool:
    """Админ: либо ID в ADMIN_IDS из .env, либо Manage Server / Administrator в гильдии."""
    if interaction.user.id in ADMIN_IDS:
        return True
    if not interaction.guild:
        return False
    try:
        perms = interaction.user.guild_permissions
        if perms.administrator or perms.manage_guild:
            return True
    except AttributeError:
        pass
    return False


@bot.tree.command(
    name="архив",
    description="Зарегистрировать дело в архиве (бот принимает данные в канале 1 → частичный ответ в ch1 + ПОЛНЫЙ в ch2)",
)
@app_commands.describe(
    прокурор="Имя и фамилия прокурора",
    субъекты="Субъекты дела",
    структура="Фракция / Структура (через запятую если несколько, можно писать что угодно)",
    ссылка="Ссылка на Google Docs",
    номер="Номер дела (можно писать что угодно)",
    повод="Повод для возбуждения дела",
)
async def archive_cmd(
    interaction: discord.Interaction,
    прокурор: str,
    субъекты: str,
    структура: str,
    ссылка: str,
    номер: str,
    повод: str,
) -> None:
    # === ROBUST DEFER ===
    # Самая частая причина "Unknown interaction 10062" — бот получил команду,
    # но interaction token уже умер (бот был выключен, перезапускался, reconnect, или команда вызвана слишком рано).
    # Мы ловим это сразу, логируем чисто и выходим, не порождая огромный traceback.
    try:
        await interaction.response.defer(ephemeral=True)
    except discord.NotFound as exc:
        if getattr(exc, "code", None) == 10062 or "Unknown interaction" in str(exc):
            log.warning(
                "Interaction 10062 (Unknown interaction) на этапе defer. "
                "Команда была вызвана пока бот не был готов / оффлайн / reconnect / только стартовал. "
                "Пользователь увидел 'The application did not respond'. Пропускаем."
            )
            return
        raise
    except Exception:
        log.exception("Неожиданная ошибка при defer() в команде /архив")
        return

    if not _channel_ok(interaction):
        await interaction.followup.send(
            f"Эта команда доступна только в настроенном канале архива (ID {ALLOWED_CHANNEL_ID}).\n"
            f"Используй команду в самом канале или внутри треда/поста этого канала.",
            ephemeral=True,
        )
        return

    structures = [s.strip() for s in структура.replace(";", ",").split(",") if s.strip()]

    # === ВАЛИДАЦИЯ (раньше была в form_submit, теперь прямо здесь — бот самодостаточный) ===
    prosecutor = прокурор.strip()
    subjects = субъекты.strip()
    docs_link = ссылка.strip()
    case_number = номер.strip()
    reason = повод.strip()

    if not prosecutor:
        await interaction.followup.send("❌ Имя прокурора не может быть пустым.", ephemeral=True)
        return
    if not subjects:
        await interaction.followup.send("❌ Субъекты дела не могут быть пустыми.", ephemeral=True)
        return
    if not docs_link.startswith("http"):
        await interaction.followup.send("❌ Ссылка на Google Docs должна начинаться с http(s)://", ephemeral=True)
        return
    if not reason:
        await interaction.followup.send("❌ Повод для возбуждения не может быть пустым.", ephemeral=True)
        return

    # === УСПЕХ: бот сразу шлёт ответы в Discord (ТОЛЬКО БОТ, без форм/вебхуков/GAS) ===
    # Safe ephemeral confirmation (truncate long reason to avoid 2000 char limit)
    reason_short = reason if len(reason) <= 450 else (reason[:447] + "...")

    # Защищаем followup: если interaction token уже протух (Unknown interaction 10062),
    # всё равно пытаемся сделать публичные посты в ch1 и ch2 — они используют обычный токен бота.
    try:
        await interaction.followup.send(
            f"✅ Дело зарегистрировано ботом.\n\n"
            f"**Прокурор:** {prosecutor}\n"
            f"**Номер дела:** {case_number}\n"
            f"**Структура:** {', '.join(structures)}\n"
            f"**Повод для возбуждения:** {reason_short}",
            ephemeral=True,
        )
    except Exception:
        log.exception("Не удалось отправить ephemeral подтверждение пользователю (возможно 10062 Unknown interaction). Публичные посты в каналы продолжаем.")
        # Не return — публичные embeds в ch1/ch2 важнее приватного подтверждения.


    # Частичный embed в канал 1 (тот, где была команда / thread внутри него)
    if interaction.channel is not None:
        embed = discord.Embed(
            title="📁 Дело зарегистрировано в архиве",
            color=0x2ecc71,
        )
        _add_field_safe(embed, "Прокурор", prosecutor, inline=True)
        _add_field_safe(embed, "Номер дела", case_number, inline=True)
        _add_field_safe(embed, "Структура", ", ".join(structures), inline=True)
        _add_field_safe(embed, "Повод для возбуждения", reason, inline=False)
        embed.set_footer(text=f"Отправил: {interaction.user}")
        try:
            await interaction.channel.send(embed=embed)
        except Exception:
            log.exception("Не удалось отправить публичное сообщение о деле в канал")

    # === ПОЛНАЯ ВЕРСИЯ В АРХИВНЫЙ КАНАЛ (ch2) ===
    # Бот шлёт чистый полный Embed со всеми полями (субъекты + ссылка).
    # _add_field_safe защищает от лимита 1024 символа на поле (разбивает длинные на "продолжение N").
    # Только бот из Discord Developer Portal. Никаких GAS/вебхуков.
    if ARCHIVE_CHANNEL_ID is not None:
        log.info("Попытка отправки ПОЛНОЙ версии дела %s в архивный канал %s (ch2)", case_number, ARCHIVE_CHANNEL_ID)
        try:
            archive_ch = interaction.client.get_channel(ARCHIVE_CHANNEL_ID)
            if archive_ch is None:
                archive_ch = await interaction.client.fetch_channel(ARCHIVE_CHANNEL_ID)

            full_embed = discord.Embed(
                title="📁 ПОЛНАЯ РЕГИСТРАЦИЯ ДЕЛА — АРХИВ",
                color=0x3498db,
                description="Полная копия регистрации (только через Discord бота /архив).",
            )
            _add_field_safe(full_embed, "Прокурор", prosecutor, inline=True)
            _add_field_safe(full_embed, "Номер дела", case_number or "—", inline=True)
            _add_field_safe(full_embed, "Структура", ", ".join(structures) or "—", inline=True)
            _add_field_safe(full_embed, "Субъекты дела", subjects, inline=False)
            _add_field_safe(full_embed, "Повод для возбуждения", reason, inline=False)
            _add_field_safe(full_embed, "Ссылка на документы", docs_link, inline=False)
            full_embed.set_footer(text=f"Отправил: {interaction.user}")

            await archive_ch.send(embed=full_embed)
            log.info("Полная версия дела %s отправлена ботом в архивный канал %s", case_number, ARCHIVE_CHANNEL_ID)
        except Exception:
            log.exception("Не удалось отправить ПОЛНУЮ версию в архивный канал %s", ARCHIVE_CHANNEL_ID)

    log.info("Archived case %s by %s (pure bot, ch1+ch2)", case_number, interaction.user)


@bot.tree.command(
    name="синхронизировать",
    description="Пересинхронизировать slash-команды (для админов, после изменений кода)",
)
async def sync_cmd(interaction: discord.Interaction) -> None:
    if not _is_admin(interaction):
        await interaction.response.send_message(
            "❌ Эта команда только для администраторов (ADMIN_IDS в .env или Manage Server).",
            ephemeral=True,
        )
        return

    await interaction.response.defer(ephemeral=True)

    try:
        tree = interaction.client.tree
        if GUILD_ID is not None:
            guild = discord.Object(id=GUILD_ID)
            await tree.sync(guild=guild)
            await tree.sync()
            await interaction.followup.send(
                f"✅ Команды пересинхронизированы на сервере {GUILD_ID} (сразу) + глобально (до ~1ч).",
                ephemeral=True,
            )
            log.info("Manual /синхронизировать by %s (guild+global)", interaction.user)
            return

        await tree.sync()
        await interaction.followup.send(
            "✅ Глобальная синхронизация slash-команд выполнена (появятся до ~1 часа).",
            ephemeral=True,
        )
        log.info("Manual /синхронизировать by %s (global only)", interaction.user)
    except Exception:
        log.exception("Ошибка manual sync")
        await interaction.followup.send(
            "❌ Не удалось синхронизировать команды. Проверь права бота и наличие на сервере.",
            ephemeral=True,
        )


@bot.event
async def on_ready() -> None:
    log.info("Бот запущен: %s (id=%s)", bot.user, bot.user.id if bot.user else "?")
    if not bot.guilds:
        log.warning(
            "Бот НЕ на сервере! Запусти invite.bat или добавь бота по ссылке из Developer Portal."
        )
    else:
        for guild in bot.guilds:
            log.info("Подключён к серверу: %s (id=%s)", guild.name, guild.id)

    if GUILD_ID is not None:
        in_target_guild = any(g.id == GUILD_ID for g in bot.guilds)
        if not in_target_guild:
            log.warning(
                "GUILD_ID=%s указан в .env, но бот не состоит в этом сервере. "
                "Синхронизация slash-команд на уровне сервера не сработает (403 Missing Access). "
                "Добавь бота через invite.bat и перезапусти.",
                GUILD_ID,
            )
        else:
            log.info("Бот присутствует на целевом сервере (GUILD_ID=%s) — guild-команды должны быть доступны сразу.", GUILD_ID)

    log.info("Команда /архив разрешена только в канале с ID: %s", ALLOWED_CHANNEL_ID)
    if ARCHIVE_CHANNEL_ID is not None:
        log.info("Полная регистрация (embed) будет отправляться в архивный канал (ch2) с ID: %s", ARCHIVE_CHANNEL_ID)
    else:
        log.warning("ARCHIVE_CHANNEL_ID не задан — полные embeds в ch2 не будут отправляться!")


def main() -> None:
    try:
        bot.run(TOKEN, log_handler=None)
    except discord.LoginFailure:
        log.error(
            "Неверный DISCORD_TOKEN. В Developer Portal: Bot → Reset Token, "
            "скопируй токен вида XXXX.XXXX.XXXX (не публичный ключ приложения)."
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
